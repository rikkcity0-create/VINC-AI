import { useEffect, useRef, useState, type FormEvent, type KeyboardEvent, type ReactNode } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { useSendConversationMessage } from '@workspace/api-client-react';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';
import {
  Activity, AudioLines, Bot, Check, CircleHelp, Clock3, Mic, MicOff,
  MoreHorizontal, Send, Settings2, ShieldCheck, Sparkles, Trash2, Volume2, VolumeX, X,
} from 'lucide-react';
import { Route, Switch, useLocation, Router as WouterRouter } from 'wouter';

type Message = { id: string; role: 'user' | 'assistant'; text: string; time: number; source?: 'ai' | 'local-demo' };
type Preferences = {
  assistantName: string;
  autoSpeak: boolean;
  voiceName: string;
  rate: number;
  pitch: number;
  volume: number;
  voiceSettingsVersion: number;
};
type RecognitionResult = { 0: { transcript: string }; isFinal: boolean };
type RecognitionEvent = { resultIndex: number; results: ArrayLike<RecognitionResult> };
type RecognitionErrorEvent = { error: string };
type LocalRecognition = {
  lang: string;
  interimResults: boolean;
  maxAlternatives: number;
  continuous: boolean;
  onstart: (() => void) | null;
  onresult: ((event: RecognitionEvent) => void) | null;
  onerror: ((event: RecognitionErrorEvent) => void) | null;
  onend: (() => void) | null;
  start: () => void;
  stop: () => void;
};
type RecognitionWindow = Window & {
  SpeechRecognition?: new () => LocalRecognition;
  webkitSpeechRecognition?: new () => LocalRecognition;
};

const queryClient = new QueryClient();
const CHAT_KEY = 'vinc-ai-conversation-v1';
const PREF_KEY = 'vinc-ai-preferences-v1';
const DEVICE_DEFAULT_VOICE = '__device_default__';
const VOICE_PREVIEW_TEXT = 'Hi, I’m VINC. Take a breath. We can work through this together, one small step at a time.';
const defaultPreferences: Preferences = {
  assistantName: 'VINC',
  autoSpeak: true,
  voiceName: '',
  rate: 0.95,
  pitch: 1.05,
  volume: 1,
  voiceSettingsVersion: 2,
};

const feminineVoiceNameHints = /\b(female|woman|samantha|ava|aria|jenny|emma|olivia|sara|karen|victoria|zira|susan|moira|tessa|allison|libby|amy|joanna|kendra|kimberly|salli|lucia|kate|serena)\b|wavenet[- ]f|neural2[- ]f|standard[- ]c/i;

function isLikelyFeminineVoice(voice: SpeechSynthesisVoice): boolean {
  return feminineVoiceNameHints.test(voice.name);
}

function speechVoiceScore(voice: SpeechSynthesisVoice): number {
  const lang = voice.lang.toLowerCase().replace('_', '-');
  const englishScore = lang.startsWith('en-') || lang === 'en' ? 70 : 0;
  const localeScore = lang.startsWith('en-us') ? 25 : lang.startsWith('en-gb') ? 22 : 0;
  const feminineScore = isLikelyFeminineVoice(voice) ? 50 : 0;
  const naturalNameScore = /\b(natural|neural|enhanced|premium|wavenet|studio)\b/i.test(voice.name) ? 10 : 0;
  const localServiceScore = voice.localService ? 2 : 0;
  return englishScore + localeScore + feminineScore + naturalNameScore + localServiceScore;
}

function rankSpeechVoices(voices: SpeechSynthesisVoice[]): SpeechSynthesisVoice[] {
  return [...voices].sort((a, b) =>
    speechVoiceScore(b) - speechVoiceScore(a)
    || a.lang.localeCompare(b.lang)
    || a.name.localeCompare(b.name),
  );
}

function speechVoiceKey(voice: SpeechSynthesisVoice): string {
  return voice.voiceURI || `${voice.name}::${voice.lang}`;
}

function findSpeechVoice(voices: SpeechSynthesisVoice[], preference: string): SpeechSynthesisVoice | undefined {
  return voices.find((voice) => speechVoiceKey(voice) === preference)
    ?? voices.find((voice) => voice.name === preference);
}

function readPreferences(): Preferences {
  const stored = readStored(PREF_KEY, defaultPreferences);
  try {
    const savedValue = localStorage.getItem(PREF_KEY);
    const saved = savedValue ? JSON.parse(savedValue) as Partial<Preferences> : {};
    const needsVoiceUpgrade = saved.voiceSettingsVersion !== 2;
    const bounded = (value: unknown, fallback: number, min: number, max: number) =>
      typeof value === 'number' && Number.isFinite(value) ? Math.min(max, Math.max(min, value)) : fallback;
    return {
      ...stored,
      autoSpeak: needsVoiceUpgrade ? true : stored.autoSpeak,
      rate: bounded(needsVoiceUpgrade && saved.rate === 1 ? defaultPreferences.rate : stored.rate, defaultPreferences.rate, 0.75, 1.2),
      pitch: bounded(needsVoiceUpgrade && saved.pitch === 1 ? defaultPreferences.pitch : stored.pitch, defaultPreferences.pitch, 0.8, 1.3),
      volume: bounded(saved.volume ?? defaultPreferences.volume, defaultPreferences.volume, 0, 1),
      voiceSettingsVersion: 2,
    };
  } catch {
    return defaultPreferences;
  }
}

function readStored<T,>(key: string, fallback: T): T {
  try {
    const value = localStorage.getItem(key);
    if (!value) return fallback;
    const parsed: unknown = JSON.parse(value);
    if (Array.isArray(fallback)) {
      return (Array.isArray(parsed) ? parsed : fallback) as T;
    }
    if (fallback && typeof fallback === 'object' && parsed && typeof parsed === 'object' && !Array.isArray(parsed)) {
      return { ...fallback, ...parsed } as T;
    }
    return fallback;
  } catch {
    return fallback;
  }
}

function readConversation(): Message[] {
  return readStored<Message[]>(CHAT_KEY, []).map((message) => (
    message.role === 'assistant' && !message.source
      ? { ...message, source: 'local-demo' }
      : message
  ));
}

function conversationErrorMessage(error: unknown): string {
  if (error && typeof error === 'object' && 'data' in error) {
    const data = (error as { data?: unknown }).data;
    if (data && typeof data === 'object' && 'error' in data && typeof data.error === 'string') {
      return data.error;
    }
  }
  return 'VINC could not reach Gemini right now. Check your connection and try again.';
}

function Home() {
  const conversationMutation = useSendConversationMessage();
  const [messages, setMessages] = useState<Message[]>(readConversation);
  const [preferences, setPreferences] = useState<Preferences>(readPreferences);
  const [draft, setDraft] = useState('');
  const [thinking, setThinking] = useState(false);
  const [listening, setListening] = useState(false);
  const [speaking, setSpeaking] = useState(false);
  const [voiceError, setVoiceError] = useState('');
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [availableVoices, setAvailableVoices] = useState<SpeechSynthesisVoice[]>([]);
  const logRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const recognitionRef = useRef<LocalRecognition | null>(null);
  const conversationRequestRef = useRef(0);
  const speechRequestRef = useRef(0);
  const transcriptPrefixRef = useRef('');
  const finalTranscriptRef = useRef('');
  const messagesRef = useRef(messages);
  messagesRef.current = messages;

  useEffect(() => {
    try { localStorage.setItem(CHAT_KEY, JSON.stringify(messages)); } catch { /* Storage may be unavailable. */ }
  }, [messages]);
  useEffect(() => {
    try { localStorage.setItem(PREF_KEY, JSON.stringify(preferences)); } catch { /* Storage may be unavailable. */ }
  }, [preferences]);
  useEffect(() => {
    if (!('speechSynthesis' in window)) return;
    const synthesis = window.speechSynthesis;
    const refreshVoices = () => setAvailableVoices(rankSpeechVoices(synthesis.getVoices()));
    refreshVoices();
    synthesis.addEventListener('voiceschanged', refreshVoices);
    let attempts = 0;
    const poll = window.setInterval(() => {
      refreshVoices();
      attempts += 1;
      if (synthesis.getVoices().length > 0 || attempts >= 12) window.clearInterval(poll);
    }, 250);
    return () => {
      synthesis.removeEventListener('voiceschanged', refreshVoices);
      window.clearInterval(poll);
    };
  }, []);
  useEffect(() => {
    if (!availableVoices.length || !preferences.voiceName || preferences.voiceName === DEVICE_DEFAULT_VOICE) return;
    const matchingVoice = findSpeechVoice(availableVoices, preferences.voiceName);
    if (!matchingVoice) {
      setPreferences((current) => ({ ...current, voiceName: '' }));
    } else if (preferences.voiceName !== speechVoiceKey(matchingVoice)) {
      setPreferences((current) => ({ ...current, voiceName: speechVoiceKey(matchingVoice) }));
    }
  }, [availableVoices, preferences.voiceName]);
  useEffect(() => {
    if (logRef.current) logRef.current.scrollTop = logRef.current.scrollHeight;
  }, [messages, thinking]);
  useEffect(() => () => {
    conversationRequestRef.current += 1;
    recognitionRef.current?.stop();
    window.speechSynthesis?.cancel();
  }, []);

  const updatePreference = <K extends keyof Preferences>(key: K, value: Preferences[K]) => {
    setPreferences((current) => ({ ...current, [key]: value }));
  };

  const interruptSpeech = () => {
    speechRequestRef.current += 1;
    window.speechSynthesis?.cancel();
    setSpeaking(false);
  };

  const speak = (
    text: string,
    voiceOverride?: SpeechSynthesisVoice | null,
    failedVoiceUris: string[] = [],
  ) => {
    if (!('speechSynthesis' in window)) {
      setVoiceError('Read-aloud is not supported by this browser.');
      return;
    }
    const requestId = ++speechRequestRef.current;
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    const selectedVoice = preferences.voiceName === DEVICE_DEFAULT_VOICE
      ? undefined
      : findSpeechVoice(availableVoices, preferences.voiceName)
        ?? rankSpeechVoices(availableVoices)[0];
    const voice = voiceOverride !== undefined ? voiceOverride ?? undefined : selectedVoice;
    if (voice) utterance.voice = voice;
    utterance.rate = preferences.rate;
    utterance.pitch = preferences.pitch;
    utterance.volume = preferences.volume;
    setSpeaking(true);
    utterance.onstart = () => {
      if (requestId === speechRequestRef.current) setSpeaking(true);
    };
    utterance.onend = () => {
      if (requestId === speechRequestRef.current) setSpeaking(false);
    };
    utterance.onerror = (event) => {
      if (requestId !== speechRequestRef.current) return;
      setSpeaking(false);
      if (event.error === 'voice-unavailable') {
        const failed = [...failedVoiceUris, ...(voice ? [speechVoiceKey(voice)] : [])];
        const fallbackVoice = rankSpeechVoices(availableVoices).find((candidate) => !failed.includes(speechVoiceKey(candidate)));
        if (fallbackVoice) {
          speak(text, fallbackVoice, failed);
          return;
        }
        if (voice) {
          speak(text, null, failed);
          return;
        }
      }
      if (event.error !== 'canceled' && event.error !== 'interrupted') {
        setVoiceError('Your browser could not play this voice. Try another voice or check your device audio.');
      }
    };
    setVoiceError('');
    window.speechSynthesis.speak(utterance);
  };

  const submitText = async (value = draft) => {
    const text = value.trim();
    if (!text || thinking) return;
    if (recognitionRef.current) {
      recognitionRef.current.stop();
      recognitionRef.current = null;
      setListening(false);
    }
    interruptSpeech();
    const userMessage: Message = { id: `${Date.now()}-user`, role: 'user', text, time: Date.now() };
    const nextMessages = [...messagesRef.current, userMessage];
    messagesRef.current = nextMessages;
    setMessages(nextMessages);
    setDraft('');
    setThinking(true);
    setVoiceError('');
    if (textareaRef.current) textareaRef.current.style.height = 'auto';
    const requestId = conversationRequestRef.current + 1;
    conversationRequestRef.current = requestId;
    const context = nextMessages
      .filter((message) => message.role === 'user' || message.source === 'ai')
      .slice(-16)
      .map((message) => ({
        role: message.role,
        content: message.text.slice(0, 4000),
      }));

    try {
      const result = await conversationMutation.mutateAsync({ data: { messages: context } });
      if (requestId !== conversationRequestRef.current) return;
      const reply = result.reply.trim();
      if (!reply) throw new Error('Empty Gemini response');
      const response: Message = {
        id: `${Date.now()}-assistant`,
        role: 'assistant',
        text: reply,
        time: Date.now(),
        source: 'ai',
      };
      const updated = [...messagesRef.current, response];
      messagesRef.current = updated;
      setMessages(updated);
      if (preferences.autoSpeak) speak(response.text);
    } catch (error) {
      if (requestId === conversationRequestRef.current) {
        setVoiceError(conversationErrorMessage(error));
      }
    } finally {
      if (requestId === conversationRequestRef.current) setThinking(false);
    }
  };

  const toggleListening = () => {
    setVoiceError('');
    if (listening) {
      recognitionRef.current?.stop();
      setListening(false);
      return;
    }
    if (recognitionRef.current) return;
    if (!window.isSecureContext && location.hostname !== 'localhost') {
      setVoiceError('Microphone access requires a secure connection. Open VINC through HTTPS or type a message instead.');
      return;
    }
    interruptSpeech();
    const SpeechRecognition = (window as RecognitionWindow).SpeechRecognition
      ?? (window as RecognitionWindow).webkitSpeechRecognition;
    if (!SpeechRecognition) {
      setVoiceError('Voice input is not supported here. Try Chrome on Android or enter a message below.');
      return;
    }
    try {
      const recognition = new SpeechRecognition();
      recognition.lang = navigator.language || 'en-US';
      recognition.interimResults = true;
      recognition.maxAlternatives = 1;
      recognition.continuous = false;
      transcriptPrefixRef.current = draft.trim();
      finalTranscriptRef.current = '';
      recognition.onstart = () => setListening(true);
      recognition.onresult = (event) => {
        if (recognitionRef.current !== recognition) return;
        let interimTranscript = '';
        for (let i = event.resultIndex; i < event.results.length; i += 1) {
          const result = event.results[i];
          const transcript = result[0].transcript.trim();
          if (result.isFinal) {
            finalTranscriptRef.current = [finalTranscriptRef.current, transcript].filter(Boolean).join(' ');
          } else {
            interimTranscript = [interimTranscript, transcript].filter(Boolean).join(' ');
          }
        }
        const updatedDraft = [
          transcriptPrefixRef.current,
          finalTranscriptRef.current,
          interimTranscript,
        ].filter(Boolean).join(' ');
        if (updatedDraft) setDraft(updatedDraft);
      };
      recognition.onerror = (event) => {
        if (recognitionRef.current !== recognition) return;
        const messagesByError: Record<string, string> = {
          'not-allowed': 'Microphone permission was blocked. Allow microphone access for VINC in Chrome site settings, or type a message instead.',
          'permission-denied': 'Microphone permission was blocked. Allow microphone access for VINC in Chrome site settings, or type a message instead.',
          'service-not-allowed': 'Your browser voice service is unavailable. You can still type below.',
          'no-speech': 'I didn’t catch any speech. Try again or type your message.',
          'audio-capture': 'No microphone was found. Connect one or type your message.',
          network: 'The browser voice service could not connect. Try again or type your message.',
        };
        if (event.error !== 'aborted') {
          setVoiceError(messagesByError[event.error] ?? 'Voice input stopped unexpectedly. Please try again or type your message.');
        }
        setListening(false);
        recognitionRef.current = null;
      };
      recognition.onend = () => {
        if (recognitionRef.current !== recognition) return;
        setListening(false);
        recognitionRef.current = null;
      };
      recognitionRef.current = recognition;
      recognition.start();
      setListening(true);
    } catch {
      recognitionRef.current = null;
      setListening(false);
      setVoiceError('Microphone access could not start. Check your browser permissions and try again.');
    }
  };

  const clearConversation = () => {
    if (messagesRef.current.length && !window.confirm('Clear this conversation from this device?')) return;
    conversationRequestRef.current += 1;
    setThinking(false);
    setMessages([]);
    messagesRef.current = [];
    setVoiceError('');
    window.speechSynthesis?.cancel();
    setSpeaking(false);
  };

  const handleSubmit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    submitText();
  };
  const handleKeyDown = (event: KeyboardEvent<HTMLTextAreaElement>) => {
    if (event.key === 'Enter' && !event.shiftKey) {
      event.preventDefault();
      submitText();
    }
  };
  const statusText = listening ? 'Listening' : speaking ? 'Speaking' : thinking ? 'Thinking' : 'Idle';
  const voiceStatus = listening ? 'listening' : speaking ? 'speaking' : thinking ? 'thinking' : 'idle';
  const canSpeak = 'speechSynthesis' in window;
  const recommendedVoice = availableVoices[0];

  const renderSettings = (mobile = false) => (
    <aside className={`settings-panel${mobile ? ' mobile-open' : ''}`} aria-label="Assistant and voice settings">
      <div className="panel-title-row">
        <div><h2 className="panel-title">Your VINC</h2><p className="panel-caption">A little more like you.</p></div>
        <Settings2 size={17} strokeWidth={1.7} color="#748078" />
      </div>
      <section className="settings-section">
        <label className="setting-label" htmlFor="assistant-name">Assistant name</label>
        <p className="setting-description">Choose what your companion is called.</p>
        <input id="assistant-name" className="setting-input" maxLength={22} value={preferences.assistantName}
          onChange={(event) => updatePreference('assistantName', event.target.value)} />
      </section>
      <section className="settings-section">
        <div className="setting-label"><span>Voice output</span><Volume2 size={14} color="#638a79" /></div>
        <p className="setting-description">Uses actual voices from your device. English voices and feminine-sounding names are ranked first; names are only a best-effort hint, so preview to choose what sounds right.</p>
        <select className="setting-select" aria-label="Choose a preferred voice" value={preferences.voiceName}
          onChange={(event) => updatePreference('voiceName', event.target.value)} disabled={!canSpeak}>
          <option value="">Recommended voice{recommendedVoice ? ` · ${recommendedVoice.name} (${recommendedVoice.lang})` : ' · browser default when available'}</option>
          <option value={DEVICE_DEFAULT_VOICE}>Device default voice</option>
          {availableVoices.map((voice, index) => (
            <option key={speechVoiceKey(voice)} value={speechVoiceKey(voice)}>
              {voice.name} · {voice.lang}{isLikelyFeminineVoice(voice) ? ' · likely feminine' : ''}{index === 0 ? ' · recommended' : ''}
            </option>
          ))}
        </select>
        <div className="voice-preview-row">
          <button type="button" className="voice-preview-button" disabled={!canSpeak}
            onClick={() => speaking ? interruptSpeech() : speak(VOICE_PREVIEW_TEXT)}>
            {speaking ? <VolumeX size={14} /> : <Volume2 size={14} />}
            {speaking ? 'Stop voice' : 'Preview voice'}
          </button>
          <span className="voice-preview-hint">{availableVoices.length ? 'Uses selected voice' : canSpeak ? 'Uses device default' : 'Speech not supported'}</span>
        </div>
        <div className="range-row"><span>Speaking pace</span><span className="range-value">{preferences.rate.toFixed(2)}×</span>
          <input aria-label="Speaking pace" type="range" min="0.75" max="1.2" step="0.05" value={preferences.rate}
            onChange={(event) => updatePreference('rate', Number(event.target.value))} /></div>
        <div className="range-row"><span>Voice tone</span><span className="range-value">{preferences.pitch.toFixed(2)}</span>
          <input aria-label="Voice tone" type="range" min="0.8" max="1.3" step="0.05" value={preferences.pitch}
            onChange={(event) => updatePreference('pitch', Number(event.target.value))} /></div>
        <div className="range-row"><span>Volume</span><span className="range-value">{Math.round(preferences.volume * 100)}%</span>
          <input aria-label="Speech volume" type="range" min="0" max="1" step="0.05" value={preferences.volume}
            onChange={(event) => updatePreference('volume', Number(event.target.value))} /></div>
        <div className="toggle-row" style={{ marginTop: 16 }}>
          <span className="toggle-copy">Read replies aloud</span>
          <button className="switch" role="switch" aria-checked={preferences.autoSpeak} aria-label="Read replies aloud"
            onClick={() => updatePreference('autoSpeak', !preferences.autoSpeak)} />
        </div>
      </section>
      <section className="settings-section">
        <div className="setting-label"><span>Keep this conversation</span><Clock3 size={14} color="#818a80" /></div>
        <p className="setting-description">Saved on this device so you can pick up where you left off.</p>
        <button className="clear-button" onClick={clearConversation}><Trash2 size={13} /> Clear conversation</button>
      </section>
      <div className="privacy-note"><ShieldCheck size={15} /><span>VINC uses Gemini’s Free tier; usage limits apply. Your messages and recent chat context are sent to Google, and free-tier content may be used to improve its products. Avoid sharing sensitive information. Chat and settings are saved on this device; browser voice may use its speech service.</span></div>
    </aside>
  );

  return (
    <div className="app-shell">
      <header className="topbar">
        <div className="brand">
          <div className="brand-mark"><AudioLines size={19} strokeWidth={1.8} /></div>
          <span className="brand-name">VINC</span><span className="brand-tag">PERSONAL VOICE</span>
        </div>
        <div className="top-actions">
          <span className="local-badge"><span className="local-dot" />GEMINI AI · FREE TIER</span>
          <button className="icon-button mobile-settings" onClick={() => setSettingsOpen((open) => !open)}
            aria-label={settingsOpen ? 'Close settings' : 'Open settings'} title="Settings">
            {settingsOpen ? <X size={18} /> : <Settings2 size={18} />}
          </button>
          <button className="icon-button" onClick={clearConversation} aria-label="Clear conversation" title="Clear conversation"><MoreHorizontal size={20} /></button>
        </div>
      </header>

      <main className="main-layout">
        <section className="conversation-column" aria-label="Conversation with VINC">
          <div className="session-heading">
            <div><div className="eyebrow">Personal space / 01</div><h1 className="session-title">A moment for you.</h1>
              <p className="session-note">A personal place to think out loud.</p></div>
            <button className="icon-button session-menu" aria-label="About VINC" title="About VINC"
              onClick={() => setVoiceError('VINC uses Gemini’s Free tier for live answers. Recent messages are sent to Google; free-tier content may be used to improve products. Avoid sharing sensitive information.')}>
              <CircleHelp size={18} />
            </button>
          </div>

          <div className={`orb-stage ${voiceStatus}`} aria-label={`Assistant status: ${statusText}`}>
            <span className="voice-live-status" role="status" aria-live="polite">{statusText}</span>
            <div className={`orb ${voiceStatus}`} aria-hidden="true" />
            <div className={`orb-speaking${speaking ? ' active' : listening ? ' listening-wave' : ''}`} aria-hidden="true"><span /><span /><span /><span /><span /></div>
            {speaking ? (
              <button type="button" className="orb-caption speech-interrupt" onClick={interruptSpeech} aria-label="Stop speaking">
                <VolumeX size={12} /> Speaking · tap to interrupt
              </button>
            ) : (
              <div className="orb-caption" role="status" aria-live="polite">{statusText}</div>
            )}
          </div>

          <div className="chat-log" ref={logRef} aria-live="polite" aria-label="Conversation">
            {messages.length === 0 ? (
              <div className="welcome-card">
                <div className="welcome-kicker"><Sparkles size={13} /> Here, with you</div>
                <h2>Where would you like to begin?</h2>
                <p>Replies are generated by Gemini. Recent chat history is sent with each message for context. Google may use Free-tier content to improve its products, so avoid sharing sensitive information.</p>
                <div className="suggestion-row">
                  {['Help me find focus', 'Let’s make a plan', 'I need a moment'].map((suggestion) => (
                    <button key={suggestion} className="suggestion" onClick={() => submitText(suggestion)}>{suggestion}</button>
                  ))}
                </div>
              </div>
            ) : messages.map((message) => (
              <div key={message.id}>
                <div className={`message ${message.role}`}>
                  <div className="message-mark">{message.role === 'user' ? <Check size={14} /> : <Bot size={14} />}</div>
                  <div className="message-body">
                    {message.source === 'local-demo' && <span className="message-source">Earlier local demo response</span>}
                    {message.text}
                  </div>
                </div>
                {message.role === 'assistant' && (
                  <div className="message-tools">
                    <button className="tiny-action" onClick={() => speak(message.text)} aria-label="Read reply aloud" title="Read aloud">
                      {canSpeak ? <Volume2 size={13} /> : <VolumeX size={13} />} Read aloud
                    </button>
                  </div>
                )}
              </div>
            ))}
            {thinking && <div className="message assistant"><div className="message-mark"><Bot size={14} /></div><div className="message-body"><div className="typing-indicator" aria-label="VINC is waiting for Gemini"><i /><i /><i /></div></div></div>}
          </div>

          {voiceError && <div className="voice-error" role="status"><Activity size={14} /><span>{voiceError}</span><button onClick={() => setVoiceError('')} aria-label="Dismiss message"><X size={14} /></button></div>}
          <div className="composer-wrap">
            <form className="composer" onSubmit={handleSubmit}>
              <textarea ref={textareaRef} rows={1} value={draft} onChange={(event) => {
                setDraft(event.target.value);
                event.target.style.height = 'auto';
                event.target.style.height = `${Math.min(event.target.scrollHeight, 110)}px`;
              }} onKeyDown={handleKeyDown} placeholder="Say what’s on your mind…" aria-label="Write a message" maxLength={4000} />
              <button type="button" className={`composer-button mic-button${listening ? ' is-listening' : ''}`}
                onClick={toggleListening} aria-pressed={listening}
                aria-label={listening ? 'Stop listening' : speaking ? 'Interrupt speech and start listening' : 'Start voice input'}
                title={listening ? 'Stop listening' : speaking ? 'Interrupt and listen' : 'Speak'}>
                {listening ? <MicOff size={18} /> : <Mic size={18} />}
              </button>
              <button type="submit" className="composer-button send-button" disabled={!draft.trim() || thinking}
                aria-label="Send message" title="Send message"><Send size={17} /></button>
            </form>
            <div className="composer-hint"><span>ENTER TO SEND · SHIFT + ENTER FOR A NEW LINE</span><span>{listening ? 'MICROPHONE ACTIVE' : 'SENT TO GEMINI'}</span></div>
          </div>
          {settingsOpen && <div className="mobile-settings-area">{renderSettings(true)}</div>}
        </section>

        {renderSettings()}
      </main>
      <footer className="footer"><span>VINC / PERSONAL VOICE COMPANION</span><span><ShieldCheck size={11} style={{ verticalAlign: '-2px', marginRight: 5 }} />GEMINI AI · BROWSER VOICE</span></footer>
    </div>
  );
}

function Router() {
  return (
    <RoutedErrorBoundary>
      <Switch>
        <Route path="/" component={Home} />
        <Route component={NotFound} />
      </Switch>
    </RoutedErrorBoundary>
  );
}

function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
