import { GoogleGenAI } from "@google/genai";
import { SendConversationMessageBody, SendConversationMessageResponse } from "@workspace/api-zod";
import { Router, type IRouter } from "express";
import { logger } from "../lib/logger";

const router: IRouter = Router();
const modelName = "gemini-3.8-flash";
const maxRequestsPerMinute = 20;
const rateWindowMs = 60_000;
let rateWindowStartedAt = Date.now();
let requestsInWindow = 0;

const systemInstruction = [
  "You are VINC, a personal AI assistant.",
  "Be intelligent, friendly, confident, respectful, and warm.",
  "Answer questions, explain concepts, solve problems, and help with everyday tasks.",
  "Be clear and conversational. Match the user's level of detail and avoid unnecessary filler.",
  "Ask a focused clarifying question when important information is missing.",
  "Be honest about uncertainty and never claim you completed an action you did not perform.",
].join(" ");

function consumeRequestSlot(): boolean {
  const now = Date.now();
  if (now - rateWindowStartedAt >= rateWindowMs) {
    rateWindowStartedAt = now;
    requestsInWindow = 0;
  }
  if (requestsInWindow >= maxRequestsPerMinute) return false;
  requestsInWindow += 1;
  return true;
}

function getProviderStatus(error: unknown): number | undefined {
  if (!error || typeof error !== "object" || !("status" in error)) return undefined;
  const status = Number(error.status);
  return Number.isFinite(status) ? status : undefined;
}

router.post("/conversation", async (req, res) => {
  const parsed = SendConversationMessageBody.safeParse(req.body);
  if (!parsed.success || parsed.data.messages.at(-1)?.role !== "user") {
    return res.status(400).json({ error: "Send a valid conversation ending with your message." });
  }

  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    return res.status(503).json({ error: "VINC's Gemini connection is not configured. Check the server secret." });
  }

  if (!consumeRequestSlot()) {
    return res.status(429).json({ error: "VINC is receiving messages too quickly. Wait a minute and try again." });
  }

  try {
    const ai = new GoogleGenAI({
      apiKey,
      apiVersion: "v1beta",
      httpOptions: {
        timeout: 30_000,
        retryOptions: { attempts: 1 },
      },
    });
    const response = await ai.models.generateContent({
      model: modelName,
      contents: parsed.data.messages.map((message) => ({
        role: message.role === "assistant" ? "model" : "user",
        parts: [{ text: message.content }],
      })),
      config: {
        systemInstruction,
        maxOutputTokens: 900,
      },
    });

    const reply = response.text?.trim();
    if (!reply) {
      return res.status(502).json({ error: "Gemini returned an empty response. Please try again." });
    }

    return res.json(SendConversationMessageResponse.parse({ reply }));
  } catch (error) {
    const providerStatus = getProviderStatus(error);
    const isRateLimited = providerStatus === 429;
    const isKeyRejected = providerStatus === 401 || providerStatus === 403;
    const isUnavailable = providerStatus === 503;
    const isTimeout = error instanceof Error && /timeout|timed out/i.test(`${error.name} ${error.message}`);
    const providerMessage = error instanceof Error
      ? error.message.slice(0, 500).replaceAll(apiKey, "[REDACTED]")
      : "Unknown provider error";

    const providerMessage = error instanceof Error
      ? error.message.slice(0, 500).replaceAll(apiKey, "[REDACTED]")
      : "Unknown provider error";

const providerMessage = error instanceof Error
  ? error.message.slice(0, 500).replaceAll(apiKey, "[REDACTED]")
  : "Unknown provider error";

logger.error(
  { providerStatus, errorName: error instanceof Error ? error.name : "UnknownError", providerMessage },
  "Gemini response generation failed",
);
    ););
    const status = isRateLimited ? 429 : isUnavailable || isKeyRejected ? 503 : isTimeout ? 504 : 502;
    return res.status(status).json({
      error: isRateLimited
        ? "Gemini's Free tier is temporarily at its request limit. Wait a moment and try again."
        : isKeyRejected
          ? "Gemini rejected the server API key. Check the GEMINI_API_KEY secret."
          : isUnavailable
            ? "Gemini is temporarily unavailable. Try again shortly."
            : isTimeout
              ? "Gemini is taking too long to respond. Try again shortly."
              : "VINC could not reach Gemini right now. Check your connection and try again.",
    });
  }
});

export default router;
